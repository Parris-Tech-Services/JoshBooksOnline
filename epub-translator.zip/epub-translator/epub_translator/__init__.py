"""EPUB Translator - Translate French EPUBs to English."""

__version__ = "0.1.0"
