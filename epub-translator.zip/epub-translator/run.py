"""EPUB Translator main entry point for console script."""

import sys

from epub_translator.main import main

if __name__ == "__main__":
    sys.exit(main())
