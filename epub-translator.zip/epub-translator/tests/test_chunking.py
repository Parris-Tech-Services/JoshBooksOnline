"""Tests for text chunking functionality."""

import pytest

from epub_translator.utils import chunk_text


class TestChunking:
    """Test text chunking logic."""

    def test_empty_text(self):
        """Empty string should return empty list."""
        assert chunk_text("") == []
        assert chunk_text("   ") == []

    def test_short_text_not_split(self):
        """Text under 500 chars should not be split."""
        text = "This is a short sentence. " * 5
        assert len(text) < 500
        result = chunk_text(text)
        assert len(result) == 1
        assert result[0] == text.strip()

    def test_long_text_splits_at_sentences(self):
        """Text over 500 chars should split at sentence boundaries."""
        # Create text > 500 chars
        sentence = "This is a test sentence. " * 30  # ~750 chars
        assert len(sentence) > 500
        
        result = chunk_text(sentence)
        assert len(result) > 1
        
        # Each chunk should be under 500 chars
        for chunk in result:
            assert len(chunk) <= 500

    def test_split_at_period(self):
        """Should split at periods."""
        text = "First sentence. " * 40  # ~640 chars
        result = chunk_text(text)
        assert len(result) >= 2
        assert all(chunk.endswith(".") or "." not in chunk for chunk in result)

    def test_split_at_question_mark(self):
        """Should split at question marks."""
        text = "Is this a question? " * 30  # ~600 chars
        result = chunk_text(text)
        assert len(result) >= 2

    def test_split_at_exclamation(self):
        """Should split at exclamation marks."""
        text = "This is important! " * 30  # ~570 chars
        result = chunk_text(text)
        assert len(result) >= 2

    def test_no_empty_chunks(self):
        """Should not produce empty chunks."""
        text = "Sentence one. Sentence two. " * 20
        result = chunk_text(text)
        assert all(chunk.strip() for chunk in result)

    def test_preserves_whitespace(self):
        """Should preserve reasonable whitespace."""
        text = "First sentence.  Second sentence." * 20
        result = chunk_text(text)
        # Chunks should not have excessive whitespace
        assert not any("  " in chunk for chunk in result)

    def test_custom_max_size(self):
        """Should respect custom max chunk size."""
        text = "A " * 200  # ~400 chars
        result = chunk_text(text, max_chunk_size=100)
        # With smaller max size, should create more chunks
        assert all(len(chunk) <= 100 for chunk in result)
