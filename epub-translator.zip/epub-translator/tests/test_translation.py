"""Tests for base translator interface."""

import pytest

from epub_translator.translator.base import BaseTranslator
from epub_translator.translator.argos_provider import ArgosTranslator
from epub_translator.translator.deepl_provider import DeepLTranslator
from epub_translator.translator.openai_provider import OpenAITranslator
from epub_translator.translator.libretranslate_provider import LibreTranslateTranslator


class MockTranslator(BaseTranslator):
    """Mock translator for testing."""

    def translate(self, text: str) -> str:
        """Return fixed output for testing."""
        return f"[TRANSLATED] {text}"


class TestBaseTranslator:
    """Test base translator interface."""

    def test_base_translator_not_implemented(self):
        """BaseTranslator.translate should raise NotImplementedError."""
        translator = BaseTranslator()
        with pytest.raises(TypeError):
            # Can't instantiate abstract class
            pass

    def test_mock_translator_works(self):
        """Mock translator should work for testing."""
        translator = MockTranslator()
        result = translator.translate("Hello")
        assert result == "[TRANSLATED] Hello"

    def test_deepl_not_implemented(self):
        """DeepL provider should raise NotImplementedError."""
        translator = DeepLTranslator()
        with pytest.raises(NotImplementedError):
            translator.translate("test")

    def test_openai_not_implemented(self):
        """OpenAI provider should raise NotImplementedError."""
        translator = OpenAITranslator()
        with pytest.raises(NotImplementedError):
            translator.translate("test")

    def test_libretranslate_not_implemented(self):
        """LibreTranslate provider should raise NotImplementedError."""
        translator = LibreTranslateTranslator()
        with pytest.raises(NotImplementedError):
            translator.translate("test")


class TestArgosTranslator:
    """Test Argos translator."""

    def test_argos_initialization(self):
        """Argos translator should initialize."""
        try:
            translator = ArgosTranslator()
            # Check if model installed status is boolean
            assert isinstance(translator.is_model_installed(), bool)
        except ImportError:
            # Argos not installed, skip
            pytest.skip("Argos Translate not installed")

    @pytest.mark.skipif(True, reason="Requires model installation")
    def test_argos_translate(self):
        """Argos translator should translate text."""
        translator = ArgosTranslator()
        if not translator.is_model_installed():
            pytest.skip("French-to-English model not installed")

        result = translator.translate("Bonjour")
        assert isinstance(result, str)
        assert len(result) > 0
