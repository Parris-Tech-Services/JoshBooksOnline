"""Tests for checkpoint manager."""

import json
import tempfile
from pathlib import Path

import pytest

from epub_translator.checkpoint import CheckpointManager


class TestCheckpointManager:
    """Test checkpoint manager."""

    def setup_method(self):
        """Set up test fixtures."""
        self.manager = CheckpointManager()
        self.test_hash = "abc123def456"

    def teardown_method(self):
        """Clean up after tests."""
        checkpoint_path = self.manager._get_checkpoint_path(self.test_hash)
        if checkpoint_path.exists():
            checkpoint_path.unlink()

    def test_checkpoint_directory_created(self):
        """Checkpoint directory should be created."""
        assert self.manager.CHECKPOINT_DIR.exists()

    def test_save_checkpoint(self):
        """Should save checkpoint to file."""
        chapters = [0, 1, 2]
        total = 10
        paths = ["ch1.html", "ch2.html", "ch3.html"]
        translated = {0: "<p>Translated 1</p>", 1: "<p>Translated 2</p>"}

        success = self.manager.save_checkpoint(
            self.test_hash, chapters, total, paths, translated
        )
        assert success
        
        checkpoint_path = self.manager._get_checkpoint_path(self.test_hash)
        assert checkpoint_path.exists()

    def test_load_checkpoint(self):
        """Should load saved checkpoint."""
        chapters = [0, 1]
        total = 5
        paths = ["ch1.html", "ch2.html"]
        translated = {0: "<p>T1</p>", 1: "<p>T2</p>"}

        self.manager.save_checkpoint(self.test_hash, chapters, total, paths, translated)
        
        loaded = self.manager.load_checkpoint(self.test_hash)
        assert loaded is not None
        assert loaded["completed_chapters"] == chapters
        assert loaded["total_chapters"] == total

    def test_load_missing_checkpoint(self):
        """Should return None for missing checkpoint."""
        loaded = self.manager.load_checkpoint("nonexistent_hash")
        assert loaded is None

    def test_cleanup_checkpoint(self):
        """Should delete checkpoint file."""
        chapters = [0]
        self.manager.save_checkpoint(self.test_hash, chapters, 1, ["ch1.html"], {})
        
        checkpoint_path = self.manager._get_checkpoint_path(self.test_hash)
        assert checkpoint_path.exists()
        
        success = self.manager.cleanup_checkpoint(self.test_hash)
        assert success
        assert not checkpoint_path.exists()

    def test_mark_checkpoint_complete(self):
        """Should mark checkpoint as complete."""
        chapters = [0, 1, 2]
        self.manager.save_checkpoint(self.test_hash, chapters, 3, ["ch1", "ch2", "ch3"], {})
        
        success = self.manager.mark_checkpoint_complete(self.test_hash)
        assert success
        
        checkpoint_path = self.manager._get_checkpoint_path(self.test_hash)
        with open(checkpoint_path) as f:
            data = json.load(f)
        assert data["status"] == "complete"
